import requests
import json

url = "http://billing.1000vibes.com.199-79-62-165.plesk-web22.webhostbox.net/api/User/Login"
headers = {
    "sec-ch-ua-platform": "\"Windows\"",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0",
    "sec-ch-ua": "\"Microsoft Edge\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "DNT": "1",
    "Content-Type": "application/json",
    "sec-ch-ua-mobile": "?0",
}
payload = {
    "Email": "test1@gmail.com",
    "Password": "78945"
}

raw_body = json.dumps(payload)
response = requests.post(url, data=raw_body, headers=headers)

print("Status Code:", response.status_code)
print("Raw Response Text:", response.json())

try:
    data = response.json()
    print("Parsed JSON:", data)
except ValueError:
    print("Response is not JSON. Fallback to raw text.")
